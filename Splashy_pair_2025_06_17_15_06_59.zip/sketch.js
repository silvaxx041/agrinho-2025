function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

let arvoreImg;
let predioImg;

function preload() {
  // Pré-carrega imagens se for usar. Para este exemplo, desenharemos formas simples.
  // arvoreImg = loadImage('caminho/para/sua/arvore.png');
  // predioImg = loadImage('caminho/para/seu/predio.png');
}

function setup() {
  createCanvas(800, 600);
  noLoop(); // Usaremos redesenhar com eventos de mouse/teclado para um festejo interativo
}

function draw() {
  background(200); // Cor de fundo inicial

  // --- Parte do Campo (Esquerda) ---
  fill(100, 150, 50); // Verde para o campo
  rect(0, 0, width / 2, height); // Metade esquerda da tela

  // Sol no campo
  fill(255, 200, 0);
  ellipse(width / 4, 100, 80, 80);

  // Desenhar algumas árvores simples
  drawArvore(width / 4 - 80, height - 150);
  drawArvore(width / 4 + 80, height - 180);

  // --- Parte da Cidade (Direita) ---
  fill(120, 120, 120); // Cinza para a cidade
  rect(width / 2, 0, width / 2, height); // Metade direita da tela

  // Lua na cidade
  fill(200, 200, 255);
  ellipse(width * 3 / 4, 100, 70, 70);

  // Desenhar alguns prédios simples
  drawPredio(width / 2 + 50, height - 200, 80, 180);
  drawPredio(width / 2 + 150, height - 250, 100, 230);
  drawPredio(width / 2 + 280, height - 150, 70, 130);

  // Linha de "fronteira"
  stroke(0);
  line(width / 2, 0, width / 2, height);

  // Título
  fill(0);
  textSize(32);
  textAlign(CENTER, TOP);
  text("Festejando Campo e Cidade", width / 2, 20);
}

// Função para desenhar uma árvore simples
function drawArvore(x, y) {
  fill(139, 69, 19); // Tronco marrom
  rect(x, y, 20, 100);
  fill(34, 139, 34); // Folhas verdes
  ellipse(x + 10, y, 80, 80);
  ellipse(x - 15, y + 20, 60, 60);
  ellipse(x + 35, y + 20, 60, 60);
}

// Função para desenhar um prédio simples
function drawPredio(x, y, w, h) {
  fill(80, 80, 80); // Cor do prédio
  rect(x, y, w, h);
  fill(255, 255, 100); // Janelas (amarelas, como se estivessem acesas)
  let windowSize = 10;
  let gap = 5;
  for (let i = 0; i < floor(h / (windowSize + gap)); i++) {
    for (let j = 0; j < floor(w / (windowSize + gap)); j++) {
      if (random(1) > 0.3) { // Aleatoriamente algumas janelas acesas
        rect(x + gap + j * (windowSize + gap), y + gap + i * (windowSize + gap), windowSize, windowSize);
      }
    }
  }
}

function mousePressed() {
  redraw(); // Redesenha a cena com novas janelas acesas
}

function keyPressed() {
  if (key === 'c' || key === 'C') {
    // Exemplo: mudar o sol para a lua ou vice-versa
    // Você pode expandir para transformar a cena, como dia/noite
    console.log("Transformando a cena!");
    // Para um efeito de festejo, poderíamos adicionar confetes ou luzes piscando
    // Aqui seria o lugar para chamar funções de animação.
  }
}